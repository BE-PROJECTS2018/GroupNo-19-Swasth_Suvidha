
//= require rails-ujs
//= require turbolinks
//= require_tree .



        $(function() {

            var entries = [];
            // <!-- here you can change json link-->
            var dmJSON = "https://api.thingspeak.com/channels/438181/feeds.json?results=5";
            $.getJSON( dmJSON, function(data) {
                $.each(data.feeds, function(i, f) {
                    var tblRow = "<tr>" + "<td>" + f.entry_id + "</td>" + "<td>" + f.field1 + "</td>" +  "<td> " + f.created_at + "</td>" + "</tr>"
                    var hvrRow = "<tr>" + "<td>" + f.entry_id + "</td>" + "<td>" + f.field2 + "</td>" + "<td> " + f.created_at + "</td>" + "</tr>"
                    $(tblRow).appendTo("#entrydata tbody");
                    $(hvrRow).appendTo("#hvrdata tbody");
                });

            });
            
            $.getJSON( dmJSON, function(data) {
                $.each(data.feeds, function(i, f) {
                    var hr= f.field1;
                    $(hr).appendTo("#heartdata span");
                });

            });
            
            
            

        });

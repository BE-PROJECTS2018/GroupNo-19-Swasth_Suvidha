class RegistrationsController < Devise::RegistrationsController
 
end

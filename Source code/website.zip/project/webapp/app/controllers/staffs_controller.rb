class Staffs::RegistrationsController < Devise::RegistrationsController


end

class HomeController < ApplicationController
  #before_action :authenticate_user!
  before_action do
  if current_staff != nil
   authenticate_staff!        
  else
   authenticate_user!
  end
end

  def index
  end
  
  def table
    
  end

  def charts
    
  end
  def monitor
    
  end

  def user_listing
  	@user = User.all
  	
  end

  def staff_listing
  	@staff = Staff.all
  end
end

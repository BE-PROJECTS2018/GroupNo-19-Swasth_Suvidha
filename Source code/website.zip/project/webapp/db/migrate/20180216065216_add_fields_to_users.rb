class AddFieldsToUsers < ActiveRecord::Migration[5.1]
    def change
      add_column :users , :first_name, :string
      add_column :users , :last_name, :string
      add_column :users , :username, :string
      add_column :users , :age, :integer
      add_column :users , :no_of_family_members, :integer
      add_column :users , :blood_group, :string
      add_column :users , :address, :text
      add_column :users , :city, :string
      add_column :users , :state, :string
      add_column :users , :postal_code, :string
      add_column :users , :phone_no, :string
      add_column :users , :emergency_phone_no, :string
      add_column :users , :patient_history, :text
    end
end

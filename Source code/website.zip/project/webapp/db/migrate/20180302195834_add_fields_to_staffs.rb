class AddFieldsToStaffs < ActiveRecord::Migration[5.1]
  def change
      add_column :staffs , :first_name, :string
      add_column :staffs , :last_name, :string
      add_column :staffs , :username, :string
      add_column :staffs , :age, :integer
      add_column :staffs , :blood_group, :string
      add_column :staffs , :address, :text
      add_column :staffs , :city, :string
      add_column :staffs , :state, :string
      add_column :staffs , :postal_code, :string
      add_column :staffs , :phone_no, :string
      add_column :staffs , :user_type, :string
      add_column :staffs , :designation, :string
    end
end

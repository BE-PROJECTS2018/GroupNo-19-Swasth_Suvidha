Rails.application.routes.draw do
  devise_for :staffs
  root 'home#index'
  get 'home/chart' ,as: :chart_page
  get 'home/table' ,as: :table_page
  get 'home/monitor' ,as: :monitor_page
  get 'home/user_listing' ,as: :user_page
  get 'home/staff_listing' ,as: :staff_page

  
  
  devise_for :users

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
